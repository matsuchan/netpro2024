public class Dish {

	private String name = "noname";
	private int valune = 0;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getValune() {
		return valune;
	}

	public void setValune(int valune) {
		this.valune = valune;
	}

	// public void cook(){}

}// Dishend